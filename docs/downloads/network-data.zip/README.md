# CC 主截面确认网络数据

版本：2026-10-16冻结网络；2026-10-20发布整理。
六届合计1,542个节点、4,499条按届次和关系类型计的确认边。
confirmed_edges.csv 仅含CC选举前一日截面；relation_evidence.csv 仅含这些边引用的确认依据。
metrics_cc.csv、layer_summary.csv 与此截面对齐；coverage.csv 描述人物资料覆盖。
24个GraphML分别对应六届×四类关系；SVG为六届默认全关系静态图。
一般校友包含同期校友；请勿直接相加得出唯一联系人。
缺失不等于0；无连边不等于无关系；regression_ready=false。
证据摘录保留原网站链接，完整缓存原文和未决候选留存于本地研究档案。
未纳入省市CPED数据库；不得将本包称为完整中央成员或完整官员网络。
